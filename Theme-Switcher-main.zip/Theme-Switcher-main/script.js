let bgContainerElement = document.getElementById("bgContainer");
let headingElement = document.getElementById("heading");
let themeUserInputElement = document.getElementById("themeUserInput");

function changeTheme(event) {
    let inputValue = themeUserInputElement.value;
    if (event.key === "Enter") {
        if (inputValue === "Dark") {
            bgContainerElement.style.backgroundImage = "url('https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-dark-bg.png')";
            headingElement.style.color = "white";
        } else if (inputValue === "Light") {
            bgContainerElement.style.backgroundImage = "url('https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-light-bg.png')";
            headingElement.style.color = "#014d40";
        } else {
            alert("enter the valid theme!");
        }
    }

}
themeUserInputElement.addEventListener("keydown", changeTheme);